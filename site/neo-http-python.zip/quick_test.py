"""Read real Neo position and gray JPEG using Python 3.8+ standard library only."""
import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from client import Device


def capture(device, channel, count, seconds, folder):
    result = {'channel': channel, 'received': 0, 'ok': False}
    deadline = time.monotonic() + seconds
    stream = device.observe([channel])
    try:
        for name, fmt, seq, data in stream:
            if time.monotonic() >= deadline:
                raise TimeoutError('等待有效数据超时；请检查 VIO 初始化和设备状态')
            if name == 'control':
                continue
            if name == 'odometry':
                if data['pose'] is None:
                    continue
                with (folder / 'poses.jsonl').open('a', encoding='utf-8') as f:
                    f.write(json.dumps(data, ensure_ascii=False, allow_nan=False) + '\n')
                result['last_pose'] = data
                print(json.dumps({'channel': name, 'header': data['header'], 'pose': data['pose']}, ensure_ascii=False), flush=True)
            else:
                filename = 'image-%03d.jpg' % (result['received'] + 1)
                raw = bytes(data['data'])
                (folder / filename).write_bytes(raw)
                info = {'file': filename, 'header': data['header'], 'config': data['config'],
                        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                result.setdefault('images', []).append(info)
                print(json.dumps(info, ensure_ascii=False), flush=True)
            result['received'] += 1
            if result['received'] >= count:
                result['ok'] = True
                break
        if not result['ok']:
            raise RuntimeError('设备提前关闭数据流，尚未收齐数据')
    except Exception as e:
        result['error'] = '%s: %s' % (type(e).__name__, e)
    finally:
        stream.close()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--address', default='http://192.168.11.1')
    parser.add_argument('--channel', choices=['both', 'odometry', 'gray_jpeg'], default='both')
    parser.add_argument('--count', type=int, default=3)
    parser.add_argument('--seconds', type=int, default=15, help='Per-stream deadline; stalled read may add up to 10s')
    parser.add_argument('--output', default='neo-results')
    args = parser.parse_args()
    if not 1 <= args.count <= 100 or not 1 <= args.seconds <= 120:
        parser.error('count 必须为 1–100，seconds 必须为 1–120')
    device = Device(args.address)
    folder = Path(args.output) / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S-%fZ')
    folder.mkdir(parents=True, exist_ok=False)
    report = {'address': args.address, 'output': str(folder.resolve()), 'read_only': True,
              'position_reference': 'IMU', 'position_unit': 'metre',
              'note': '两路顺序订阅，图像与位姿不是同步配对帧。', 'results': []}
    c = device.connection()
    try:
        c.request('GET', '/api/vio')
        r = c.getresponse()
        report['vio_http_status'] = r.status
        report['vio_status'] = json.loads(r.read(65537))
    except Exception as e:
        report['status_error'] = str(e)
    finally:
        c.close()
    channels = ['odometry', 'gray_jpeg'] if args.channel == 'both' else [args.channel]
    for channel in channels:
        result = capture(device, channel, args.count, args.seconds, folder)
        report['results'].append(result)
        if not result['ok']:
            print(json.dumps(result, ensure_ascii=False), file=sys.stderr)
    report['ok'] = all(r['ok'] for r in report['results'])
    (folder / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print('REPORT: ' + str((folder / 'report.json').resolve()), flush=True)
    return 0 if report['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())

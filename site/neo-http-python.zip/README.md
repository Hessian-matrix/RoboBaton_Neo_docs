# Neo HTTP 快速测试 · Python

解压后四个 Python 文件保持在同一目录：quick_test.py、client.py、transport.py、camera_model.py。Python 3.8+，仅标准库，无需 pip、ROS 或仓库源码。

维护/重新打包时，client.py、transport.py、camera_model.py 必须取自 SDK/python/robobaton_sdk；tools/http-api 下的同名文件只适合仓库内旧路径兼容，不可当作独立客户端发布。单文件生成器 build_quick_test.py 也以 SDK 源码为基准。

连接设备 USB 网络，先在设备现有网页启动 VIO 并等待有效定位。运行：

    python quick_test.py --address http://192.168.11.1 --channel both --count 3 --seconds 15 --output neo-results

Windows 也可用 py -3，macOS/Linux 通常用 python3。AI-PROMPT.md 可直接复制给能操作这台电脑的 AI 助手；云端聊天执行环境不能访问你的设备局域网。

默认顺序读取 3 条位置和 3 张灰度 JPEG。只发 GET /api/vio、GET /api/stream?channels=odometry、GET /api/stream?channels=gray_jpeg，不修改设备。每次创建独立时间戳目录，不覆盖旧结果。

输出 poses.jsonl、image-001.jpg 等图片及 report.json。位置以 IMU 为参考、单位米，四元数字段 x/y/z/w；两路不是同步配对。仅位姿可选 --channel odometry，仅图像可选 --channel gray_jpeg。

退出码 0 表示所选流均收齐；1 表示至少一路失败，请查看报告。VIO 空位姿不计数；保留设备警告（例如 CALIBRATION_REQUIRED），收到数据不等于标定准确或精度验收通过。每路等待默认15秒，单次阻塞读取最多额外10秒；状态查询最多10秒。

需要本机已有 Python；没有时由用户决定是否安装。接口解析使用随包公开客户端，包含 RBH1 分片、元数据、序号及数据结构校验；图片仍需用图片查看器解码查看。请勿把浏览器 WASM 示例当成本机网络客户端运行。
